from pathlib import Path
import chromadb
from app.rag.embeddings import embed

from pathlib import Path
import chromadb
from app.rag.embeddings import embed

BASE_DIR = Path(__file__).resolve().parents[3]
DB_PATH = BASE_DIR / "vector_db"

print("CHROMA DB PATH:", DB_PATH)

client = chromadb.PersistentClient(
    path=str(DB_PATH)
)

print("CHROMA DB PATH:", DB_PATH)

client = chromadb.PersistentClient(
    path=str(DB_PATH)
)


def get_collection(collection_name: str):
    return client.get_or_create_collection(
        name=collection_name
    )


def add_document(
    document_id: str,
    chunks: list[str],
    collection_name: str,
):
    collection = get_collection(collection_name)

    embeddings = embed(chunks)

    ids = [
        f"{document_id}_{i}"
        for i in range(len(chunks))
    ]

    collection.add(
        ids=ids,
        documents=chunks,
        embeddings=embeddings.tolist(),
        metadatas=[
            {
                "document": document_id,
                "chunk": i,
            }
            for i in range(len(chunks))
        ],
    )


def search(
    question_embedding,
    collection_name: str,
    top_k: int = 5,
):
    collection = get_collection(collection_name)

    return collection.query(
    query_embeddings=[question_embedding.tolist()],
    n_results=top_k,
    include=[
        "documents",
        "metadatas",
        "distances",
    ],
)