import os
from pathlib import Path

from app.rag.chunker import chunk_text
from app.rag.chroma_service import add_document

SUPPORTED_EXTENSIONS = {
    ".py",
    ".js",
    ".ts",
    ".tsx",
    ".jsx",
    ".java",
    ".cpp",
    ".c",
    ".go",
    ".rs",
    ".md",
    ".txt",
    ".json",
    ".yaml",
    ".yml",
    ".toml",
}

IGNORE_DIRS = {
    ".git",
    "__pycache__",
    "node_modules",
    ".next",
    "dist",
    "build",
    ".venv",
    "venv",
    "vector_db",
    ".turbo",
    ".idea",
    ".vscode",
    ".pytest_cache",
    ".mypy_cache",
}

MAX_FILE_SIZE = 1024 * 1024  # 1 MB


def index_project(
    project_path: str,
    knowledge_base: str,
):
    project = Path(project_path)

    print("=" * 70)
    print("PROJECT =", project.resolve())
    print("=" * 70)

    if not project.exists():
        print("❌ Project path does not exist.")
        return 0

    indexed = 0

    for root, dirs, files in os.walk(project):
        print("FILES:", files[:10])

        print("\nROOT:", root)
        print("BEFORE:", dirs)

    dirs[:] = [
    d for d in dirs
    if d.lower() not in {x.lower() for x in IGNORE_DIRS}
]

    print("AFTER :", dirs)

    print("DIRS:", dirs)

    for filename in files:
            print("FILE FOUND:", filename)

            file = Path(root) / filename

            if file.suffix.lower() not in SUPPORTED_EXTENSIONS:
                continue

            if file.stat().st_size > MAX_FILE_SIZE:
                continue

            print("Reading:", file)

            try:
                text = file.read_text(
                    encoding="utf-8",
                    errors="ignore",
                )

                if not text.strip():
                    continue

                chunks = chunk_text(text)

                print("Chunks:", len(chunks))

                add_document(
                    document_id=str(file.relative_to(project)),
                    chunks=chunks,
                    collection_name=knowledge_base,
                )

                indexed += 1

                print(f"Indexed {indexed}: {file}")

                # Safety limit
                if indexed >= 10:
                    print("Reached safety limit (500 files).")
                    return indexed

            except Exception as e:
                print("FAILED:", file)
                print(e)

    print("=" * 70)
    print(f"Finished! Indexed {indexed} files.")
    print("=" * 70)

    return indexed