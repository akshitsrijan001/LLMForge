from app.rag.embeddings import embed
from app.rag.chroma_service import search


SIMILARITY_THRESHOLD = 0.35


def retrieve(
    question: str,
    collection_name: str = "default",
    top_k: int = 5,
):
    question_embedding = embed([question])[0]

    results = search(
        question_embedding,
        collection_name,
        top_k,
    )

    docs = []
    metadata = []

    returned_docs = results.get("documents", [[]])[0]
    returned_meta = results.get("metadatas", [[]])[0]
    returned_distances = results.get("distances", [[]])[0]

    for doc, meta, distance in zip(
        returned_docs,
        returned_meta,
        returned_distances,
    ):
        similarity = 1 - distance

        if similarity >= SIMILARITY_THRESHOLD:
            docs.append(doc)
            metadata.append(meta)

    return docs, metadata