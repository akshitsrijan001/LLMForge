from pathlib import Path
import chromadb

DB_PATH = Path("vector_db").resolve()

print("KB PATH:", DB_PATH)

client = chromadb.PersistentClient(
    path=str(DB_PATH)
)


def list_knowledge_bases():
    collections = client.list_collections()

    print("Collections:", collections)

    return [c.name for c in collections]


def create_knowledge_base(name: str):
    client.get_or_create_collection(name=name)


def delete_knowledge_base(name: str):

    if name == "default":
        return

    client.delete_collection(name)