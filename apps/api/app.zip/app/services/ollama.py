import json
from urllib import response
import requests

from app.services.prompt_builder import build_messages
from app.services.dspy_service import optimize_prompt
from app.core.config import settings


def check_connection():
    try:
        response = requests.get(f"{settings.OLLAMA_URL}/api/tags")
        return response.status_code == 200
    except Exception:
        return False


def installed_models():
    try:
        response = requests.get(f"{settings.OLLAMA_URL}/api/tags")
        return response.json()
    except Exception:
        return None


SYSTEM_PROMPT = """
You are LLMForge, an expert AI software engineer and technical assistant.

Rules:
- Give accurate and practical answers.
- Think step by step before answering.
- Explain concepts before writing code.
- Use GitHub Flavored Markdown.
- Wrap every code example inside fenced Markdown code blocks.
- Always specify the programming language.
- Prefer concise answers unless the user asks for more detail.
- Follow clean coding practices.
"""


def chat(
    model: str,
    prompt: str,
    history: list,
    files: list = [],
    knowledge_base: str = "default",
    generation_settings: dict | None = None,
):

    coding_keywords = [
        "python",
        "java",
        "react",
        "next",
        "fastapi",
        "bug",
        "debug",
        "error",
        "fix",
        "code",
        "algorithm",
        "typescript",
        "javascript",
        "html",
        "css",
        "sql",
    ]

    # -----------------------------
    # DSPy Prompt Optimization
    # -----------------------------
    if any(word in prompt.lower() for word in coding_keywords):
        try:
            print("🧠 DSPy Optimizing...")
            optimized_prompt = optimize_prompt(prompt, model)
        except Exception as e:
            print("⚠️ DSPy Failed:", e)
            optimized_prompt = prompt
    else:
        optimized_prompt = prompt

    print("Original :", prompt)
    print("Optimized:", optimized_prompt)

    print("STEP 1")

    messages = build_messages(
        history,
        optimized_prompt,
        files,
    )

    print("STEP 2")

    # -----------------------------
    # RAG Retrieval
    # -----------------------------
    context = ""
    sources = []

    try:
        from app.rag.retriever import retrieve

        docs, sources = retrieve(
            prompt,
            collection_name=knowledge_base,
        )

        if docs:
            print(f"✅ Retrieved {len(docs)} chunks")
            context = "\n\n".join(docs)
        else:
            print("⚠️ No relevant context found.")

    except Exception as e:
        print("Retriever Error:", e)

    print("STEP 3")

    if context:

        rag_prompt = f"""
You are answering using information retrieved from the user's knowledge base.

Answer ONLY using the context below.

If the context does not contain the answer,
say you don't know.

================ CONTEXT ================

{context}

=========================================
"""

        messages.insert(
            1,
            {
                "role": "system",
                "content": rag_prompt,
            },
        )

    # -----------------------------
    # Generation Settings
    # -----------------------------
    gen_settings = generation_settings or {}

    temperature = gen_settings.get("temperature", 0.4)
    top_p = gen_settings.get("topP", 0.95)
    num_ctx = gen_settings.get("context", 4096)

    print("========== SETTINGS ==========")
    print("Temperature:", temperature)
    print("Top P:", top_p)
    print("Context:", num_ctx)
    print("==============================")

    try:

        print(f"🤖 Model: {model}")
        print(f"📝 Prompt Length: {len(prompt)}")
        print(f"💬 History Messages: {len(history)}")
        print(f"📄 Uploaded Files: {len(files)}")

        print("STEP 4")

        response = requests.post(
            f"{settings.OLLAMA_URL}/api/chat",
            json={
                "model": model,
                "messages": messages,
                "stream": True,
                "keep_alive": "30m",
                "options": {
                    "temperature": temperature,
                    "top_p": top_p,
                    "num_ctx": num_ctx,
                    "num_predict": 512,
                },
            },
            stream=True,
            timeout=300,
        )

        response.raise_for_status()

        print("STEP 5")

        for line in response.iter_lines(decode_unicode=True):

            print("STEP 6")

            if not line:
                continue

            chunk = json.loads(line)

            if chunk.get("done"):
                break

            if "message" in chunk:
                text = chunk["message"].get("content", "")

                if text:
                    yield text

        if sources:

            yield "\n\n---\n\n"
            yield "### Sources\n\n"

            shown = set()

            for source in sources:

                key = (source["document"], source["chunk"])

                if key in shown:
                    continue

                shown.add(key)

                yield f"📄 **{source['document']}** (Chunk {source['chunk']})\n\n"

        print("✅ Response completed.")

    except requests.Timeout:
        yield "⚠️ Model timed out."

    except Exception as e:
        import traceback
        traceback.print_exc()
        yield f"⚠️ Error: {e}"